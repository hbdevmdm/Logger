package com.hb.logger.util

import androidx.core.content.FileProvider

class GenericFileProvider : FileProvider()